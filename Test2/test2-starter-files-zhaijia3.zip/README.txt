You can do the questions in any order. If you get stuck on a question move to 
the next one and come back to it.

Below is a list of the files you must submit, together with the total marks for 
each question.

[ 8 marks] q1_true_false.txt  (General)
[ 4 marks] q2_short_answer.txt(General)
[ 7 marks] q3_update_score.c  (Binary files)
[ 5 marks] q4_make.txt		  (Makefiles)
[ 9 marks] q5_pipes.txt       (Pipes)
[ 7 marks] q6_automate.c      (Processes)

[40 marks] TOTAL

There are two additional files provided: (You don't need to submit these)
q3_games 
    - a sample input file for the program in q3_update_score.c.
      This is only guaranteed to work on teach.cs.
q6_commands 
    - a sample input file for the program in q6_automate.c
